This_year = 2024

Name = input("What is your name? ")
print(f"Welcome To MUBS, {Name} ")

try:
    Age = int(input("What is your age? "))
    Birth_year = This_year - Age
    print(f"You were born in; {Birth_year}.")

except:
    print("This input is wronge please try again please! ")


try:
    Favourite_number = int(input("What is your favorite number? "))

    if Favourite_number % 2 == 0:
        print("EVEN number!")
    else:
        print("ODD number.")

    if Favourite_number > 10:
        print("Big number!")
    elif Favourite_number < 10:
        print("Small number.")
    else:
        print("Perfect Number.")

except:
    print("Wronge Input. Try again")