class Book:
    def __init__(self, title, author, year_published):
        self.title = title
        self.author = author
        self.year_published = year_published

    def description(self):
        return f"{self.title} by {self.author}, published in {self.year_published}"


def create_books():
    return [
        Book("Understanding mtc", "dave", 2006),
        Book("Simplified datacom", "ogwal", 2009),
        Book("advanced technology", "Job", 2023),
    ]

def display_books(books):
    for book in books:
        print(book.description())

def sort_books_by_year(books):
    return sorted(books, key=lambda x: x.year_published)

def search_book_by_title(books):
    while True:
        title = input("\nEnter a book title to search for (or type 'exit' to stop): ").strip()
        if title.lower() == "exit":
            break
        found_book = next((book for book in books if book.title.lower() == title.lower()), None)
        if found_book:
            print(f"Found: {found_book.description()}")
        else:
            print("Book not found.")


books = create_books()
print("All Books:")
display_books(books)

print("\nBooks Sorted by Year:")
sorted_books = sort_books_by_year(books)
display_books(sorted_books)

search_book_by_title(books)
        
   







